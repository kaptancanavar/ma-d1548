import torch
import torch.nn as nn


class ResidualBlock3D(nn.Module):
    def __init__(self, in_planes, planes, norm_fn='group', stride=1, down=False):
        super(ResidualBlock3D, self).__init__()
        self.conv1 = nn.Conv3d(in_planes, planes, kernel_size=3, padding=1, stride=stride)
        self.conv2 = nn.Conv3d(planes, planes, kernel_size=3, padding=1)
        self.relu = nn.ReLU(inplace=True)

        num_groups = planes // 8

        if norm_fn == 'group':
            self.norm1 = nn.GroupNorm(num_groups=num_groups, num_channels=planes)
            self.norm2 = nn.GroupNorm(num_groups=num_groups, num_channels=planes)
            if stride != 1:
                self.norm3 = nn.GroupNorm(num_groups=num_groups, num_channels=planes)

        elif norm_fn == 'batch':
            self.norm1 = nn.BatchNorm3d(planes)
            self.norm2 = nn.BatchNorm3d(planes)
            if stride != 1:
                self.norm3 = nn.BatchNorm3d(planes)

        elif norm_fn == 'instance':
            self.norm1 = nn.InstanceNorm3d(planes)
            self.norm2 = nn.InstanceNorm3d(planes)
            if stride != 1:
                self.norm3 = nn.InstanceNorm3d(planes)

        elif norm_fn == 'none' or down:
            self.norm1 = nn.Sequential()
            self.norm2 = nn.Sequential()
            if stride != 1:
                self.norm3 = nn.Sequential()

        if stride == 1:
            self.downsample = None
        else:
            self.downsample = nn.Sequential(
                nn.Conv3d(in_planes, planes, kernel_size=1, stride=stride), self.norm3)

        if down:
            self.norm3 = nn.BatchNorm3d(planes)
            self.downsample = nn.Sequential(
                nn.Conv3d(in_planes, planes, kernel_size=1, stride=stride), self.norm3)

    def forward(self, x):
        y = self.relu(self.norm1(self.conv1(x)))
        y = self.relu(self.norm2(self.conv2(y)))

        if self.downsample is not None:
            x = self.downsample(x)

        return self.relu(x + y)


class BasicEncoder3D(nn.Module):
    def __init__(self, output_dim=128, norm_fn='batch', dropout=0.0, num_input_channels=3, stride=2):
        super(BasicEncoder3D, self).__init__()
        self.norm_fn = norm_fn

        if norm_fn == 'group':
            self.norm1 = nn.GroupNorm(num_groups=8, num_channels=64)
        elif norm_fn == 'batch':
            self.norm1 = nn.BatchNorm3d(64)
        elif norm_fn == 'instance':
            self.norm1 = nn.InstanceNorm3d(64)
        elif norm_fn == 'none':
            self.norm1 = nn.Sequential()

        self.conv1 = nn.Conv3d(num_input_channels, 64, kernel_size=7, stride=2, padding=3)
        self.relu1 = nn.ReLU(inplace=True)

        self.in_planes = 64
        self.layer1 = self._make_layer(64, stride=1)
        self.layer2 = self._make_layer(96, stride=1, down=True)
        self.layer3 = self._make_layer(128, stride=stride)

        self.conv2 = nn.Conv3d(128, output_dim, kernel_size=1)

        self.dropout = nn.Dropout3d(p=dropout) if dropout > 0 else None

        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, (nn.BatchNorm3d, nn.InstanceNorm3d, nn.GroupNorm)):
                if m.weight is not None:
                    nn.init.constant_(m.weight, 1)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def _make_layer(self, dim, stride=1, down=False):
        layer1 = ResidualBlock3D(self.in_planes, dim, self.norm_fn, stride=stride, down=down)
        layer2 = ResidualBlock3D(dim, dim, self.norm_fn, stride=1)
        self.in_planes = dim
        return nn.Sequential(layer1, layer2)

    def forward(self, x):
        is_list = isinstance(x, (list, tuple))
        if is_list:
            batch_dim = x[0].shape[0]
            x = torch.cat(x, dim=0)

        x = self.conv1(x)
        x = self.norm1(x)
        x = self.relu1(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.conv2(x)

        if self.training and self.dropout is not None:
            x = self.dropout(x)

        if is_list:
            x = torch.split(x, [batch_dim, batch_dim], dim=0)

        return x
